using ProjetDelta.Player;
using ProjetDelta.UI;
using System;
using System.Linq;

namespace ProjetDelta.Systemes
{
    public static class CommandHandler
    {
        public static bool TryHandle(string input, Joueur joueur, IUI ui)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;
            var cmd = input.Trim().ToLowerInvariant();

            var dtos = ProjetDelta.Data.DataLoader.ArtefactLoader.GetDtos();

            switch (cmd)
            {
                case "artifacts":
                case "artefacts":
                case "art":
                case "inventaire":
                    if (joueur.Artefacts.Count == 0)
                    {
                        ui.Afficher("Aucun artefact equipe.");
                        return true;
                    }
                    ui.Afficher($"Artefacts equipes (Or: {joueur.Argent}) :");
                    foreach (var a in joueur.Artefacts)
                    {
                        var dto = dtos.FirstOrDefault(d =>
                            string.Equals(d.Nom, a.Nom, StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(d.Id, a.Nom, StringComparison.OrdinalIgnoreCase));
                        var rarity = dto?.Rarity ?? "common";
                        var desc = string.IsNullOrWhiteSpace(a.Description) ? "" : $" - {a.Description}";
                        var color = rarity.Equals("epic", StringComparison.OrdinalIgnoreCase) ? "magenta"
                                    : rarity.Equals("rare", StringComparison.OrdinalIgnoreCase) ? "blue"
                                    : "white";
                        ui.AffichageBasicInteractif("- ", "white");
                        ui.AffichageBasicInteractif($"[{rarity}] ", color);
                        ui.AffichageBasicInteractif($"{a.Nom}", color);
                        if (!string.IsNullOrWhiteSpace(desc))
                            ui.AffichageBasicInteractif($"{desc}", "white");
                        ui.TerminerLigne();
                    }
                    return true;
                default:
                    return false;
            }
        }
    }
}
