﻿using ProjetDelta.Artifacts;
using ProjetDelta.Data.DataClasses;
using ProjetDelta.Logger;
using ProjetDelta.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Player
{

    public delegate void AttackHandler(Combattant cible, ref float degats);
    public delegate void DamageTakenHandler(ref float degats);
    public abstract class Combattant
    {
        protected Attributs _attributs;
        protected Stats _stats;
        protected string _nom;
        protected string _couleur;
        private float _spdFlatBonus = 0f;
        private float _spdPctBonus = 0f;

        public virtual string Nom => _nom;
        public virtual float PV => _stats.VieCourante;
        public virtual float PVMax => _stats.VieMax;
        public virtual float SPD => (_stats.Vitesse * (1 + _spdPctBonus)) + _spdFlatBonus;
        public virtual string Couleur => _couleur;
        public float Force => _attributs?.GetForce() ?? 0;
        public float Dexterite => _attributs?.GetDex() ?? 0;
        public float Constitution => _attributs?.GetConstitution() ?? 0;
        public float Intelligence => _attributs?.GetIntel() ?? 0;
        public int Darkness => _attributs?.GetDarkness() ?? 0;
        public float LootDropBonusPct => _lootDropBonusPct;
        public float GoldBonusPct => _goldBonusPct;
        public float XpBonusPct => _xpBonusPct;

        public event Action<float, Combattant?> OnTakeDamage;

        public event AttackHandler? OnAttack;
        public event DamageTakenHandler? OnDamageTaken;
        public event Action? OnCombatStart;
        public event Action? OnCombatEnd;
        public event Action? OnEquip;
        public event Action? OnTurnStart;
        public List<IArtefact> Artefacts { get; private set; } = new();

        protected ICombatLogger _logger;
        private float _lootDropBonusPct = 0f;
        private float _goldBonusPct = 0f;
        private float _xpBonusPct = 0f;
        public void DebutCombat()
        {
            OnCombatStart?.Invoke();
        }

        public void FinCombat()
        {
            OnCombatEnd?.Invoke();
        }
        public virtual void SetLogger(ICombatLogger logger)
        {
            _logger = logger;
        }

        public virtual void EquipArtefact(IArtefact artefact)
        {
            artefact.EquipTo(this);
            artefact.Register(this);
            Artefacts.Add(artefact);
            OnEquip?.Invoke();
        }

        public void DebutTour()
        {
            OnTurnStart?.Invoke();
        }

        public virtual void Attaquer(Combattant cible, float multiplicateurDegats = 1f)
        {
            float degats = _stats.Attaque * multiplicateurDegats;
            // L'attaquant peut modifier les degats via ses artefacts avant l'application
            OnAttack?.Invoke(cible, ref degats);

            var attaqueLog = new CombatDataItem
            {
                Event = TypeEvenement.Attaque,
                NomAttaquant = _nom,
                NomRecevant = cible.Nom,
                CouleurAtt = Couleur,
                CouleurDef = cible.Couleur,
                DegatInflige = degats
            };
            _logger?.Log(attaqueLog);

            var degatsLog = new CombatDataItem
            {
                Event = TypeEvenement.Degats,
                NomAttaquant = _nom,
                NomRecevant = cible.Nom,
                CouleurAtt = Couleur,
                CouleurDef = cible.Couleur
            };

            cible.SubirDegats(degats, degatsLog, this);
        }

        public virtual void SubirDegats(float degats, CombatDataItem damageLog, Combattant? attaquant = null)
        {
            // Les artefacts defensifs peuvent reagir/ajuster les degats recus
            OnDamageTaken?.Invoke(ref degats);

            _stats.SubirDegats(degats);

            damageLog.Event = TypeEvenement.Degats;
            damageLog.CouleurDef = Couleur;
            damageLog.DegatSubi = degats;
            damageLog.NomRecevant = Nom;
            damageLog.HpCourant = _stats.VieCourante.ToString();
            damageLog.HpTotal = _stats.VieMax.ToString();

            _logger?.Log(damageLog);

            OnTakeDamage?.Invoke(degats, attaquant);
        }

        // Degats sans declencher les evenements/artefacts defensifs.
        public void SubirDegatsSansEffets(float degats)
        {
            _stats.SubirDegats(degats);
        }

        public virtual bool EstVivant() => _stats.EstVivant();

        public virtual void Heal(float amount)
        {
            // Un soin est equivalent a infliger des degats negatifs.
            if (_stats.VieCourante >= _stats.VieMax) return;
            _stats.SubirDegats(-amount);
        }

        public void LogArtefact(string artefactNom, string message, float deltaPv = 0, bool includeHp = true)
        {
            string hpCourant = includeHp ? _stats.VieCourante.ToString() : string.Empty;
            string hpTotal = includeHp ? _stats.VieMax.ToString() : string.Empty;
            _logger?.Log(new CombatDataItem
            {
                Event = TypeEvenement.Artefact,
                NomAttaquant = artefactNom,
                NomRecevant = Nom,
                Message = message,
                DegatSubi = -deltaPv,
                HpCourant = hpCourant,
                HpTotal = hpTotal,
                Type = "green",
                CouleurAtt = Couleur,
                CouleurDef = Couleur,
            });
        }

        public void AddSpeedBonus(float flat = 0f, float pct = 0f)
        {
            _spdFlatBonus += flat;
            _spdPctBonus += pct;
        }

        public void AddLootBonus(float pct)
        {
            _lootDropBonusPct += pct;
        }

        public void AddXpBonus(float pct)
        {
            _xpBonusPct += pct;
        }

        public void AddStatBonus(float pv = 0f, float attaque = 0f, float vitesse = 0f)
        {
            _stats.AjouterBonus(pv, attaque, vitesse);
        }

        public void AddLootDropBonus(float pct)
        {
            _lootDropBonusPct += pct;
            if (_lootDropBonusPct < 0) _lootDropBonusPct = 0;
        }

        public void AddGoldBonus(float pct)
        {
            _goldBonusPct += pct;
            if (_goldBonusPct < 0) _goldBonusPct = 0;
        }

        public void SetMetaBonuses(float goldPct, float lootPct)
        {
            _goldBonusPct = MathF.Max(0, goldPct);
            _lootDropBonusPct = MathF.Max(0, lootPct);
        }
    }
}
