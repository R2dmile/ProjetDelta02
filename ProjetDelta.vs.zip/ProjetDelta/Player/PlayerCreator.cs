using ProjetDelta.Data.DataClasses;
using ProjetDelta.Data.DataLoader;
using ProjetDelta.UI;
using ProjetDelta.Artifacts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetDelta.Player
{
    public class PlayerCreator
    {
        public Joueur CreationJoueur(IUI ui, IEnumerable<string>? forbiddenNames = null)
        {
            string nom = "";
            var forbidden = new HashSet<string>(forbiddenNames ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            while (true)
            {
                nom = ui.QuestionReponse("Quel est votre nom ?");
                if (string.IsNullOrWhiteSpace(nom))
                {
                    ui.Afficher("Le nom ne peut pas etre vide.");
                    continue;
                }
                if (forbidden.Contains(nom))
                {
                    ui.Afficher("Un personnage porte deja ce nom. Choisis-en un autre.");
                    continue;
                }
                break;
            }

            Background background = SelectionnerBackground(ui);
            Classe classe = SelectionnerClasse(ui);

            // Instanciation d'un nouveau joueur avec les informations recuperees
            Joueur joueur = new Joueur(nom, background, classe, new Stats());

            // Artefacts thematiques automatiques
            EquiperArtefactsThematiques(ui, joueur, background, classe);

            return joueur;
        }

        private Background SelectionnerBackground(IUI ui)
        {
            List<Background> backgrounds = BasicLoaders.ChargerBackgrounds();
            var artefactsDtos = ArtefactLoader.GetDtos()
                .Where(d => !string.IsNullOrWhiteSpace(d.Id))
                .ToDictionary(d => d.Id, d => d, StringComparer.OrdinalIgnoreCase);

            return ui.ChoisirOption(
                "Choisissez votre background :",
                backgrounds,
                b =>
                {
                    var attr = b.Attributs;
                    var artefactId = b.ArtefactId ?? "";
                    var artefactNom = (!string.IsNullOrEmpty(artefactId) && artefactsDtos.TryGetValue(artefactId, out var dto))
                        ? dto.Nom
                        : (string.IsNullOrEmpty(artefactId) ? "Artefact thematique" : artefactId);
                    return $"{b.Nom} - {b.Description} | Stats: +Intel {attr.Intel}, +Force {attr.Force}, +Const {attr.Constitution}, +Dex {attr.Dex} | Artefact: {artefactNom}";
                }
            );
        }

        private Classe SelectionnerClasse(IUI ui)
        {
            List<Classe> classes = BasicLoaders.ChargerClasses();
            var artefactsDtos = ArtefactLoader.GetDtos()
                .Where(d => !string.IsNullOrWhiteSpace(d.Id))
                .ToDictionary(d => d.Id, d => d, StringComparer.OrdinalIgnoreCase);

            return ui.ChoisirOption(
                "Choisissez votre classe :",
                classes,
                b =>
                {
                    var a = b.Attributs;
                    var artefactId = b.ArtefactId ?? "";
                    var artefactNom = (!string.IsNullOrEmpty(artefactId) && artefactsDtos.TryGetValue(artefactId, out var dto))
                        ? dto.Nom
                        : (string.IsNullOrEmpty(artefactId) ? "Artefact thematique" : artefactId);
                    return $"{b.Nom} - {b.Description} | Multiplicateurs: Intel x{a.MulIntel}, Force x{a.MulForce}, Const x{a.MulConst}, Dex x{a.MulDex} | Artefact: {artefactNom}";
                }
            );
        }

        private void EquiperArtefactsThematiques(IUI ui, Joueur joueur, Background background, Classe classe)
        {
            var artefactsDispo = ArtefactLoader.ChargerDepuisJson();

            if (!string.IsNullOrWhiteSpace(background.ArtefactId) && artefactsDispo.TryGetValue(background.ArtefactId, out var artefactBg))
            {
                joueur.EquipArtefact(artefactBg);
                ui.Afficher($"Artefact de background obtenu : {artefactBg.Nom}");
            }

            if (!string.IsNullOrWhiteSpace(classe.ArtefactId) && artefactsDispo.TryGetValue(classe.ArtefactId, out var artefactCls))
            {
                joueur.EquipArtefact(artefactCls);
                ui.Afficher($"Artefact de classe obtenu : {artefactCls.Nom}");
            }
        }
    }
}
