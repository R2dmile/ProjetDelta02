using ProjetDelta.Donjon.Monstres;
using ProjetDelta.Jeu;
using ProjetDelta.Player;
using ProjetDelta.Systemes.events;
using ProjetDelta.UI;
using ProjetDelta.Artifacts;
using ProjetDelta.Data.DataLoader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Donjon.Rooms
{
    public class CombatRoom : Room
    {
        private string _name;
        private string _description;
        private List<Monstre> _monstres;
        private Room _nextRoom;
        private bool _isBoss;

        public override string Name => _name;
        public bool IsBoss => _isBoss;

        public CombatRoom(string name, string description, List<Monstre> monstres, bool isBoss = false)
        {
            _name = name;
            _description = description;
            _monstres = monstres;
            _isBoss = isBoss;
        }

        public override void SetNextRoomName(string name)
        {
            base.SetNextRoomName(name);
        }

        public override void ResolveLinks(Dictionary<string, Room> allRooms)
        {
            if (_nextRoomName != null && allRooms.TryGetValue(_nextRoomName, out var resolved))
                _nextRoom = resolved;
        }

        public override Room GetNextRoom() => _nextRoom;

        public override void ResolveRoom(IUI ui, Joueur joueur)
        {
            ui.Afficher($"Salle Combat : {_name}");
            ui.Afficher(_description);
            ui.Afficher("Monstres presents : " + string.Join(", ", _monstres.Select(m => m.Nom)));
            ui.TerminerLigne();

            // Pause avant combat
            ui.QuestionReponse("Tape 'start' pour commencer le combat");

            var combat = new Combat(joueur, _monstres, ui);
            combat.Demarrer();
            if (!joueur.EstVivant())
            {
                throw new GameOverException("Le joueur est mort.");
            }
            Console.WriteLine("Combat termine");

            // Recompenses
            int Triangulaire(int t)
            {
                // n-th triangular number: n*(n+1)/2
                return t * (t + 1) / 2;
            }

            var goldBase = _monstres.Sum(m =>
            {
                var tier = Math.Max(1, m.Tier);
                return Triangulaire(tier) * 10;
            });
            var gold = (int)Math.Ceiling(goldBase * (1 + joueur.GoldBonusPct));
            joueur.AjouterArgent(gold);
            ui.Afficher($"Victoire ! Recompense : {gold} or (bonus: x{MathF.Round(1 + joueur.GoldBonusPct, 2)}) (argent total: {joueur.Argent})");

            // XP gagnee
            int xpGain = _monstres.Sum(m => 10 + 5 * Math.Max(0, m.Tier - 1));
            joueur.GagnerExperience(xpGain, ui);

            // Artefact bonus eventuel (autorise doublons)
            var rand = new Random();
            var chanceArtefact = 0.01 + joueur.LootDropBonusPct;
            if (rand.NextDouble() <= chanceArtefact)
            {
                var dtos = ArtefactLoader.GetDtos()
                    .Where(d => string.IsNullOrWhiteSpace(d.Rarity) || d.Rarity.Equals("common", StringComparison.OrdinalIgnoreCase))
                    .ToList();
                if (dtos.Count > 0)
                {
                    var dto = dtos[rand.Next(dtos.Count)];
                    var loot = ArtefactLoader.CreerInstance(dto.Id ?? dto.Nom ?? "");
                    if (loot != null)
                    {
                        joueur.EquipArtefact(loot);
                        var desc = dto.Description ?? loot.Description;
                        var rarity = dto.Rarity ?? "common";
                        var color = rarity.Equals("epic", StringComparison.OrdinalIgnoreCase) ? "magenta"
                                    : rarity.Equals("rare", StringComparison.OrdinalIgnoreCase) ? "blue"
                                    : "white";
                        ui.AffichageBasicInteractif("Tu trouves : ", "white");
                        ui.AffichageBasicInteractif($"[{rarity}] {loot.Nom}", color);
                        ui.TerminerLigne();
                        if (!string.IsNullOrWhiteSpace(desc))
                        {
                            ui.Afficher($"Description : {desc}");
                        }
                    }
                }
            }
        }
    }
}
