using ProjetDelta.Player;
using ProjetDelta.UI;
using ProjetDelta.Data.DataLoader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Donjon.Rooms
{
    public class TreasureRoom : Room
    {
        private string _name;
        private string _description;
        private string _treasure;
        private Room _nextRoom;

        public override string Name => _name;

        public TreasureRoom(string name, string description, string treasure)
        {
            _name = name;
            _description = description;
            _treasure = treasure;
        }

        public override void SetNextRoomName(string name)
        {
            base.SetNextRoomName(name);
        }

        public override void ResolveLinks(Dictionary<string, Room> allRooms)
        {
            if (_nextRoomName != null && allRooms.TryGetValue(_nextRoomName, out var resolved))
                _nextRoom = resolved;
        }

        public override Room GetNextRoom() => _nextRoom;

        public override void ResolveRoom(IUI ui, Joueur joueur)
        {
            ui.Afficher($"Salle Tresor : {_name}");
            ui.Afficher(_description);
            ui.Afficher($"Tu trouves : {_treasure}");

            // Artefact
            var dto = ArtefactLoader.GetDtos()
                .FirstOrDefault(d =>
                    string.Equals(d.Id, _treasure, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(d.Nom, _treasure, StringComparison.OrdinalIgnoreCase));
            if (dto != null)
            {
                ui.Afficher($"Description : {dto.Description}");
                var artefact = ArtefactLoader.CreerInstance(dto.Id);
                if (artefact != null)
                {
                    joueur.EquipArtefact(artefact);
                    ui.Afficher($"Tu as equipe : {artefact.Nom} !");
                }
                return;
            }

            // Gold fallback (parse premier nombre trouve)
            var digits = new string(_treasure.Where(char.IsDigit).ToArray());
            int gold = 0;
            if (!string.IsNullOrWhiteSpace(digits))
            {
                int.TryParse(digits, out gold);
            }
            if (gold == 0) gold = 10;
            gold = (int)Math.Ceiling(gold * (1 + joueur.GoldBonusPct));
            joueur.AjouterArgent(gold);
            ui.Afficher($"Tu empoches {gold} pieces d'or.");
        }
    }
}
