using ProjetDelta.Data.DataClasses;
using ProjetDelta.Data.DataLoader;
using ProjetDelta.Player;

namespace ProjetDelta.Artifacts
{
    public static class ArtefactFactory
    {
        public static IArtefact FromDto(ArtefactDto dto)
        {
            var type = dto.Type?.Trim().ToLowerInvariant() ?? "";
            var nom = string.IsNullOrWhiteSpace(dto.Nom) ? dto.Type : dto.Nom;
            var desc = dto.Description;
            var v1 = dto.Valeur ?? 0;
            var v2 = dto.Valeur2 ?? 0;

            return type switch
            {
                "poison" => BuildPoison(nom, desc, (int)v1),
                "heal_on_attack" or "soin_attaque" => BuildSoinSurAttaque(nom, desc, (int)v1),
                "regen_on_hit" or "regeneration" => BuildRegeneration(nom, desc, (int)v1),
                "armure_plate" or "armor_flat" => BuildArmure(nom, desc, (int)v1),
                "bouclier_pct" or "shield_pct" => BuildBouclier(nom, desc, v1),
                "vol_de_vie" or "lifesteal" => BuildVolDeVie(nom, desc, v1),
                "epines" or "thorns" => BuildEpines(nom, desc, v1, v2),
                "vitesse_flat" => BuildSpeedFlat(nom, desc, v1),
                "vitesse_pct" => BuildSpeedPct(nom, desc, v1),
                "dmg_mult" => BuildDamageMultiplier(nom, desc, v1),
                "first_strike" => BuildFirstStrike(nom, desc, v1, v2),
                "charge" => BuildCharge(nom, desc, v1, v2),
                "stat_bonus" => BuildStatBonus(nom, desc, v1, v2),
                "force_mul" => BuildForceMultiplier(nom, desc, v1),
                "dex_mul" => BuildDexMultiplier(nom, desc, v1),
                "const_mul" => BuildConstMultiplier(nom, desc, v1),
                "esquive_pct" or "dodge_pct" => BuildEsquive(nom, desc, v1),
                "loot_bonus" or "drop_bonus" => BuildLootBonus(nom, desc, v1),
                "gold_bonus" or "gold_pct" => BuildGoldBonus(nom, desc, v1),
                "xp_bonus" => BuildXpBonus(nom, desc, v1, v2),
                "combo_dmg_life" => BuildComboDmgLife(nom, desc, v1, v2),
                "combo_armor_thorns" => BuildComboArmorThorns(nom, desc, v1, v2),
                "extra_attack" => BuildExtraAttack(nom, desc),
                "rage_speed" => BuildRageSpeed(nom, desc, v1),
                "evasion_eye" => BuildEvasionEye(nom, desc, v1, v2),
                "charge_crit" => BuildChargeCrit(nom, desc, v1, v2),
                "inertie_stone" => BuildInertieStone(nom, desc, v1, v2),
                "prudent_talisman" => BuildPrudentTalisman(nom, desc, v1, v2),
                "aura_catalyst" => BuildAuraCatalyst(nom, desc, v1),
                "hermes_pair" => BuildHermesPair(nom, desc, v1, v2),
                "rage_reactor" => BuildRageReactor(nom, desc, v1, v2),
                "loot_sword" => BuildLootSword(nom, desc, v1, v2),
                "ice_hammer" => BuildIceHammer(nom, desc, v1, v2),
                "common_doubler" => BuildCommonDoubler(nom, desc),
                _ => BuildAutre(nom, desc)
            };
        }

        private static IArtefact BuildPoison(string nom, string? desc, int bonus)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{bonus} degats plats sur chaque attaque.")
                .OnAttack((Combattant source, Combattant cible, ref float degats) =>
                {
                    var avant = degats;
                    degats += bonus;
                    source.LogArtefact(nom, $"{nom} sur {cible.Nom} ajoute +{bonus} degats ({avant} -> {degats})", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildSoinSurAttaque(string nom, string? desc, int soin)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Soigne {soin} PV quand tu attaques (si tu n'es pas full PV).")
                .OnAttack((Combattant source, Combattant cible, ref float degats) =>
                {
                    if (source.PV < source.PVMax)
                    {
                        var avant = source.PV;
                        source.Heal(soin);
                        var apres = source.PV;
                        source.LogArtefact(nom, $"{nom} soigne {source.Nom} de {soin} pv ({avant}->{apres})", soin, false);
                    }
                })
                .Build();
        }

        private static IArtefact BuildRegeneration(string nom, string? desc, int soin)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Soigne {soin} PV au debut de ton tour (pas au-dessus du max).")
                .OnEquip(bearer =>
                {
                    bearer.OnTurnStart += () =>
                    {
                        if (!bearer.EstVivant()) return;
                        if (bearer.PV < bearer.PVMax)
                        {
                            var avant = bearer.PV;
                            bearer.Heal(soin);
                            var apres = bearer.PV;
                            bearer.LogArtefact(nom, $"{nom} soigne {bearer.Nom} de {soin} pv ({avant}/{bearer.PVMax}->{apres}/{bearer.PVMax})", soin, false);
                        }
                    };
                })
                .Build();
        }

        private static IArtefact BuildArmure(string nom, string? desc, int reduction)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"-{reduction} degats sur chaque coup recu.")
                .OnDamageTaken((Combattant bearer, ref float degats) =>
                {
                    var avant = degats;
                    var apres = avant - reduction;
                    if (apres < 0) apres = 0;
                    degats = apres;
                    bearer.LogArtefact(nom, $"{nom} ({bearer.Nom}) reduit les degats de {avant} a {apres}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildBouclier(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Absorbe {MathF.Round(pct * 100, 0)}% des degats recus.")
                .OnDamageTaken((Combattant bearer, ref float degats) =>
                {
                    var reduction = degats * pct;
                    degats -= reduction;
                    if (reduction > 0)
                        bearer.LogArtefact(nom, $"{nom} ({bearer.Nom}) absorbe {MathF.Round(reduction, 2)} degats", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildVolDeVie(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Soigne {MathF.Round(pct * 100, 0)}% des degats reels infliges.")
                .OnAttack((Combattant source, Combattant cible, ref float degats) =>
                {
                    Action<float, Combattant?>? handler = null;
                    handler = (degatsSubis, attaquant) =>
                    {
                        cible.OnTakeDamage -= handler;
                        if (degatsSubis <= 0) return;
                        var soin = MathF.Round(degatsSubis * pct, 2);
                        if (soin <= 0) return;
                        if (source.PV < source.PVMax)
                        {
                            var avant = source.PV;
                            source.Heal(soin);
                            var apres = source.PV;
                            source.LogArtefact(nom, $"{nom} soigne {source.Nom} de {soin} pv ({avant}->{apres})", soin, false);
                        }
                    };
                    cible.OnTakeDamage += handler;
                })
                .Build();
        }

        private static IArtefact BuildEpines(string nom, string? desc, float pct, float flat)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Renvoie {MathF.Round(pct*100,0)}% + {flat} degats a l'attaquant quand tu es touche.")
                .OnEquip(bearer =>
                {
                    bearer.OnTakeDamage += (degatsRecus, attaquant) =>
                    {
                        if (attaquant == null || !attaquant.EstVivant()) return;
                        var renvoi = flat + degatsRecus * pct;
                        renvoi = MathF.Round(renvoi, 2);
                        if (renvoi <= 0) return;

                        bearer.LogArtefact(nom, $"{nom} renvoie {renvoi} degats a {attaquant.Nom}", 0, false);

                        // Degats directs sans declencher d'autres handlers.
                        attaquant.SubirDegatsSansEffets(renvoi);
                    };
                })
                .Build();
        }

        private static IArtefact BuildSpeedFlat(string nom, string? desc, float flat)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{flat} vitesse (SPD)")
                .OnCombatStart(bearer =>
                {
                    bearer.AddSpeedBonus(flat, 0);
                    bearer.LogArtefact(nom, $"{nom} augmente la vitesse de +{flat}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildSpeedPct(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,0)}% vitesse (SPD)")
                .OnCombatStart(bearer =>
                {
                    bearer.AddSpeedBonus(0, pct);
                    bearer.LogArtefact(nom, $"{nom} augmente la vitesse de +{MathF.Round(pct*100,0)}%", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildDamageMultiplier(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,0)}% degats sur les attaques.")
                .OnAttack((Combattant source, Combattant cible, ref float degats) =>
                {
                    var avant = degats;
                    degats *= (1 + pct);
                    source.LogArtefact(nom, $"{nom} augmente les degats ({MathF.Round(avant,2)} -> {MathF.Round(degats,2)})", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildFirstStrike(string nom, string? desc, float bonusDegats, float bonusPct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Premier coup du combat : +{bonusDegats} degats ou +{MathF.Round(bonusPct*100,0)}%")
                .OnEquip(bearer =>
                {
                    bool first = true;
                    bearer.OnAttack += (Combattant cible, ref float degats) =>
                    {
                        if (!first) return;
                        first = false;
                        var avant = degats;
                        degats += bonusDegats;
                        degats *= (1 + bonusPct);
                        bearer.LogArtefact(nom, $"{nom} renforce le premier coup ({MathF.Round(avant,2)} -> {MathF.Round(degats,2)})", 0, false);
                    };
                })
                .Build();
        }

        private static IArtefact BuildCharge(string nom, string? desc, float bonusVitesse, float malusVitesse)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Un tour rapide (+{bonusVitesse} SPD), un tour lent (-{malusVitesse} SPD) en alternance.")
                .OnEquip(bearer =>
                {
                    bool rapide = true;
                    float applique = 0;
                    bearer.OnTurnStart += () =>
                    {
                        // retirer l'ancien effet
                        bearer.AddSpeedBonus(-applique, 0);
                        // appliquer le nouveau
                        applique = rapide ? bonusVitesse : -MathF.Abs(malusVitesse);
                        bearer.AddSpeedBonus(applique, 0);
                        bearer.LogArtefact(nom, rapide
                            ? $"{nom} accelere ce tour (+{bonusVitesse} SPD)"
                            : $"{nom} ralentit ce tour (-{MathF.Abs(malusVitesse)} SPD)", 0, false);
                        rapide = !rapide;
                    };
                })
                .Build();
        }

        private static IArtefact BuildStatBonus(string nom, string? desc, float hpBonus, float atkBonus)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{hpBonus} PV max et +{atkBonus} attaque")
                .OnEquip(bearer =>
                {
                    bearer.AddStatBonus(hpBonus, atkBonus, 0);
                    bearer.LogArtefact(nom, $"{nom} octroie +{hpBonus} PV et +{atkBonus} attaque", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildForceMultiplier(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,0)}% d'attaque")
                .OnEquip(bearer =>
                {
                    var bonus = bearer.Force * pct;
                    bearer.AddStatBonus(0, bonus, 0);
                    bearer.LogArtefact(nom, $"{nom} augmente l'attaque de +{MathF.Round(bonus,2)}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildDexMultiplier(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,0)}% de vitesse")
                .OnEquip(bearer =>
                {
                    var bonus = bearer.Dexterite * 0.5f * pct;
                    bearer.AddStatBonus(0, 0, bonus);
                    bearer.LogArtefact(nom, $"{nom} augmente la vitesse de +{MathF.Round(bonus,2)}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildConstMultiplier(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,0)}% de PV max")
                .OnEquip(bearer =>
                {
                    var bonus = bearer.Constitution * 5f * pct;
                    bearer.AddStatBonus(bonus, 0, 0);
                    bearer.LogArtefact(nom, $"{nom} augmente les PV de +{MathF.Round(bonus,2)}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildEsquive(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"{MathF.Round(pct*100,1)}% de chance d'esquiver un coup (annule les degats)")
                .OnDamageTaken((Combattant bearer, ref float degats) =>
                {
                    var rnd = new Random();
                    if (rnd.NextDouble() < pct)
                    {
                        degats = 0;
                        bearer.LogArtefact(nom, $"{nom} permet d'esquiver le coup !", 0, false);
                    }
                })
                .Build();
        }

        private static IArtefact BuildLootBonus(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,1)}% chance de trouver un artefact apres un combat")
                .OnEquip(bearer =>
                {
                    bearer.AddLootDropBonus(pct);
                })
                .Build();
        }

        private static IArtefact BuildGoldBonus(string nom, string? desc, float pct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,1)}% d'or gagne sur les recompenses")
                .OnEquip(bearer =>
                {
                    bearer.AddGoldBonus(pct);
                })
                .Build();
        }

        private static IArtefact BuildXpBonus(string nom, string? desc, float pct, float flatOnWin)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(pct*100,1)}% d'XP gagnee" + (flatOnWin > 0 ? $" et +{flatOnWin} XP apres chaque combat" : ""))
                .OnEquip(bearer =>
                {
                    bearer.AddXpBonus(pct);
                    if (flatOnWin > 0)
                    {
                        bearer.OnCombatEnd += () =>
                        {
                            if (bearer is Joueur j)
                            {
                                j.GagnerExperience((int)flatOnWin);
                            }
                        };
                    }
                })
                .Build();
        }

        private static IArtefact BuildComboDmgLife(string nom, string? desc, float dmgPct, float lifePct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{MathF.Round(dmgPct*100,0)}% degats et {MathF.Round(lifePct*100,0)}% vol de vie sur tes attaques.")
                .OnAttack((Combattant source, Combattant cible, ref float degats) =>
                {
                    var avant = degats;
                    degats *= (1 + dmgPct);
                    source.LogArtefact(nom, $"{nom} augmente les degats ({MathF.Round(avant,2)} -> {MathF.Round(degats,2)})", 0, false);

                    Action<float, Combattant?>? handler = null;
                    handler = (degatsSubis, attaquant) =>
                    {
                        cible.OnTakeDamage -= handler;
                        if (degatsSubis <= 0) return;
                        var soin = MathF.Round(degatsSubis * lifePct, 2);
                        if (soin <= 0) return;
                        if (source.PV < source.PVMax)
                        {
                            var avantSoin = source.PV;
                            source.Heal(soin);
                            var apresSoin = source.PV;
                            source.LogArtefact(nom, $"{nom} vole {soin} pv ({avantSoin}->{apresSoin})", soin, false);
                        }
                    };
                    cible.OnTakeDamage += handler;
                })
                .Build();
        }

        private static IArtefact BuildComboArmorThorns(string nom, string? desc, float reduction, float thornsPct)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"Reduit les degats de {reduction} et renvoie {MathF.Round(thornsPct*100,0)}% a l'attaquant.")
                .OnEquip(bearer =>
                {
                    bearer.OnDamageTaken += (ref float degats) =>
                    {
                        var avant = degats;
                        degats -= reduction;
                        if (degats < 0) degats = 0;
                        if (avant != degats)
                            bearer.LogArtefact(nom, $"{nom} reduit les degats ({avant}->{degats})", 0, false);
                    };

                    bearer.OnTakeDamage += (degatsRecus, attaquant) =>
                    {
                        if (attaquant == null || !attaquant.EstVivant()) return;
                        var renvoi = MathF.Round(degatsRecus * thornsPct, 2);
                        if (renvoi <= 0) return;
                        var pvAvant = attaquant.PV;
                        attaquant.SubirDegatsSansEffets(renvoi);
                        var pvApres = attaquant.PV;
                        bearer.LogArtefact(nom, $"{nom} renvoie {renvoi} degats a {attaquant.Nom} ({pvAvant}->{pvApres})", 0, false);
                    };
                })
                .Build();
        }

        private static IArtefact BuildAutre(string nom, string? desc)
        {
            return new ArtefactBuilder()
                .AvecNom(nom ?? "Artefact inconnu")
                .AvecDescription(desc ?? "Effet inconnu.")
                .Build();
        }

        private static IArtefact BuildExtraAttack(string nom, string? desc)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Octroie une attaque supplementaire par tour.")
                .OnEquip(bearer =>
                {
                    // Hook sur OnTurnStart pour déclencher une seconde attaque automatique sur la même cible qu'au tour
                    bearer.OnTurnStart += () =>
                    {
                        // Marquer qu'une attaque bonus sera déclenchée à la fin de l'attaque normale
                        AttackHandler? handler = null;
                        handler = (Combattant cible, ref float degats) =>
                        {
                            // Désinscrire immédiatement pour éviter les boucles
                            bearer.OnAttack -= handler;
                            // si la cible n'est plus vivante, rien
                            if (cible == null || !cible.EstVivant()) return;
                            // lancer une attaque supplémentaire avec dégâts de base (sans multiplicateur)
                            bearer.Attaquer(cible, 1f);
                            bearer.LogArtefact(nom, $"{nom} permet une attaque supplementaire sur {cible.Nom}", 0, false);
                        };
                        bearer.OnAttack += handler;
                    };
                })
                .Build();
        }

        private static IArtefact BuildRageSpeed(string nom, string? desc, float flatGain)
        {
            float bonusAccumule = 0f;
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? $"+{flatGain} SPD a chaque attaque (temporaire jusqu'a la fin du combat)")
                .OnEquip(bearer =>
                {
                    bearer.OnAttack += (Combattant cible, ref float degats) =>
                    {
                        bonusAccumule += flatGain;
                        bearer.AddSpeedBonus(flatGain, 0);
                        bearer.LogArtefact(nom, $"{nom} ajoute +{flatGain} SPD (total +{bonusAccumule})", 0, false);
                    };
                    bearer.OnCombatEnd += () =>
                    {
                        if (bonusAccumule != 0)
                        {
                            bearer.AddSpeedBonus(-bonusAccumule, 0);
                            bonusAccumule = 0;
                        }
                    };
                })
                .Build();
        }

        private static IArtefact BuildEvasionEye(string nom, string? desc, float pct, float unused)
        {
            // pct attendu : 0.20 (20% d'esquive)
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "La premiere fois que tu descends sous 30% PV, gagne +20% d'esquive pour le reste du combat.")
                .OnEquip(bearer =>
                {
                    bool triggered = false;
                    bearer.OnTurnStart += () =>
                    {
                        if (triggered) return;
                        if (bearer.PV <= bearer.PVMax * 0.3f)
                        {
                            triggered = true;
                            bearer.OnDamageTaken += (ref float degats) =>
                            {
                                var rnd = new Random();
                                if (rnd.NextDouble() < pct)
                                {
                                    degats = 0;
                                    bearer.LogArtefact(nom, $"{nom} permet d'esquiver le coup !", 0, false);
                                }
                            };
                            bearer.LogArtefact(nom, $"{nom} s'active : +{MathF.Round(pct*100,0)}% esquive jusqu'a la fin du combat.", 0, false);
                        }
                    };
                    bearer.OnCombatEnd += () => { triggered = false; };
                })
                .Build();
        }

        private static IArtefact BuildChargeCrit(string nom, string? desc, float unused, float unused2)
        {
            // Toutes les 3 attaques, la suivante fait +50% degats
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Toutes les 3 attaques, la suivante inflige +50% degats.")
                .OnEquip(bearer =>
                {
                    int compteur = 0;
                    bearer.OnAttack += (Combattant cible, ref float degats) =>
                    {
                        compteur++;
                        if (compteur >= 3)
                        {
                            compteur = 0;
                            var avant = degats;
                            degats *= 1.5f;
                            bearer.LogArtefact(nom, $"{nom} declenche un coup charge (+50%): {MathF.Round(avant,2)} -> {MathF.Round(degats,2)}", 0, false);
                        }
                    };
                    bearer.OnCombatEnd += () => compteur = 0;
                })
                .Build();
        }

        private static IArtefact BuildInertieStone(string nom, string? desc, float dmgRedPct, float spdMalusPct)
        {
            // dmgRedPct attendu : 0.10, spdMalusPct attendu : 0.05
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "-10% degats recus, -5% SPD.")
                .OnEquip(bearer =>
                {
                    bearer.OnDamageTaken += (ref float degats) =>
                    {
                        var avant = degats;
                        degats *= MathF.Max(0, 1 - dmgRedPct);
                        bearer.LogArtefact(nom, $"{nom} reduit les degats ({MathF.Round(avant,2)} -> {MathF.Round(degats,2)})", 0, false);
                    };
                    bearer.AddSpeedBonus(0, -spdMalusPct);
                })
                .Build();
        }

        private static IArtefact BuildPrudentTalisman(string nom, string? desc, float unused, float unused2)
        {
            // Premiere fois qu'un coup est recu, il est reduit de 50%
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "La premiere fois qu'un coup te touche dans un combat, il est reduit de 50%.")
                .OnEquip(bearer =>
                {
                    bool consumed = false;
                    bearer.OnDamageTaken += (ref float degats) =>
                    {
                        if (consumed) return;
                        consumed = true;
                        var avant = degats;
                        degats *= 0.5f;
                        bearer.LogArtefact(nom, $"{nom} amortit le premier coup ({MathF.Round(avant,2)} -> {MathF.Round(degats,2)})", 0, false);
                    };
                    bearer.OnCombatEnd += () => consumed = false;
                })
                .Build();
        }

        private static IArtefact BuildAuraCatalyst(string nom, string? desc, float bonusPct)
        {
            // bonusPct attendu : 0.05 (5%)
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "+5% d'efficacite sur tes artefacts defensifs (degats recus -5%, soins +5%).")
                .OnDamageTaken((Combattant bearer, ref float degats) =>
                {
                    var avant = degats;
                    degats *= MathF.Max(0, 1 - bonusPct);
                    bearer.LogArtefact(nom, $"{nom} amortit (+{bonusPct*100:0}% defense) {MathF.Round(avant,2)} -> {MathF.Round(degats,2)}", 0, false);
                })
                .OnEquip(bearer =>
                {
                    // petit boost aux soins entrants en reutilisant AddLootBonus? Non -> via OnTakeDamage hook impossible.
                    // On applique un bonus global de 5% sur les soins via AddStatBonus sur HP max pour simuler une meilleure sustain.
                    bearer.AddStatBonus(bearer.PVMax * 0.05f, 0, 0);
                })
                .Build();
        }

        private static IArtefact BuildHermesPair(string nom, string? desc, float unused, float unused2)
        {
            // Pour chaque paire d'artefacts possedes, +1 DEX (~+0.25 SPD)
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Pour chaque paire d'artefacts possedes, +1 DEX (bonus de vitesse).")
                .OnEquip(bearer =>
                {
                    float currentBonus = 0f;
                    Action recalcul = () =>
                    {
                        // retirer l'ancien bonus
                        if (currentBonus != 0) bearer.AddSpeedBonus(-currentBonus, 0);
                        int paires = (bearer.Artefacts.Count) / 2;
                        currentBonus = paires * 0.25f; // 1 dex -> 0.25 SPD
                        if (currentBonus != 0)
                        {
                            bearer.AddSpeedBonus(currentBonus, 0);
                            bearer.LogArtefact(nom, $"{nom} accorde +{currentBonus:0.00} SPD grace aux paires d'artefacts", 0, false);
                        }
                    };
                    // initial
                    recalcul();
                    // se mettre a jour a chaque equip
                    bearer.OnEquip += recalcul;
                })
                .Build();
        }

        private static IArtefact BuildRageReactor(string nom, string? desc, float unused, float unused2)
        {
            // Chaque fois qu'on attaque, on simule une reaction aux bonus de SPD : +DEX SPD et +5% degats sur ce coup
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "A chaque bonus de vitesse (simule sur chaque attaque), +DEX SPD et +5% degats sur l'attaque.")
                .OnAttack((Combattant bearer, Combattant cible, ref float degats) =>
                {
                    bearer.AddSpeedBonus(bearer.Dexterite, 0);
                    var avant = degats;
                    degats *= 1.05f;
                    bearer.LogArtefact(nom, $"{nom} amplifie la rage: SPD +{bearer.Dexterite:0.##}, degats {MathF.Round(avant,2)} -> {MathF.Round(degats,2)}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildLootSword(string nom, string? desc, float unused, float unused2)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Garanti un artefact commun apres chaque combat gagne.")
                .OnCombatEnd(bearer =>
                {
                    if (bearer is Joueur j)
                    {
                        var pool = ArtefactLoader.GetDtos()
                            .Where(d => string.IsNullOrWhiteSpace(d.Rarity) || d.Rarity.Equals("common", StringComparison.OrdinalIgnoreCase))
                            .ToList();
                        if (pool.Count == 0) return;
                        var rand = new Random();
                        var dto = pool[rand.Next(pool.Count)];
                        var art = ArtefactLoader.CreerInstance(dto.Id ?? dto.Nom ?? "");
                        if (art != null)
                        {
                            j.EquipArtefact(art);
                            j.LogArtefact(nom, $"{nom} depouille l'ennemi : {art.Nom} obtenu.", 0, false);
                        }
                    }
                })
                .Build();
        }

        private static IArtefact BuildIceHammer(string nom, string? desc, float unused, float unused2)
        {
            // Glass canon : +30% degats infliges, +20% degats recus
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Marteau de glace : +30% degats infliges, mais +20% degats recus.")
                .OnAttack((Combattant bearer, Combattant cible, ref float degats) =>
                {
                    var avant = degats;
                    degats *= 1.3f;
                    bearer.LogArtefact(nom, $"{nom} frappe fort : {MathF.Round(avant,2)} -> {MathF.Round(degats,2)}", 0, false);
                })
                .OnDamageTaken((Combattant bearer, ref float degats) =>
                {
                    var avant = degats;
                    degats *= 1.2f;
                    bearer.LogArtefact(nom, $"{nom} fragilise le porteur : {MathF.Round(avant,2)} -> {MathF.Round(degats,2)}", 0, false);
                })
                .Build();
        }

        private static IArtefact BuildCommonDoubler(string nom, string? desc)
        {
            return new ArtefactBuilder()
                .AvecNom(nom)
                .AvecDescription(desc ?? "Double les artefacts communs quand ils entrent dans l'inventaire (copie instantanee).")
                .OnEquip(bearer =>
                {
                    bearer.OnEquip += () =>
                    {
                        var recents = bearer.Artefacts.LastOrDefault();
                        if (recents == null) return;
                        if (string.Equals(recents.Nom, nom, StringComparison.OrdinalIgnoreCase)) return;

                        var dto = ArtefactLoader.GetDtos().FirstOrDefault(d =>
                            string.Equals(d.Nom, recents.Nom, StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(d.Id, recents.Nom, StringComparison.OrdinalIgnoreCase));
                        var isCommon = dto == null || string.IsNullOrWhiteSpace(dto.Rarity) || dto.Rarity.Equals("common", StringComparison.OrdinalIgnoreCase);
                        if (!isCommon) return;

                        var clone = ArtefactLoader.CreerInstance(dto?.Id ?? recents.Nom);
                        if (clone != null && bearer is Joueur j)
                        {
                            j.EquipArtefact(clone);
                            j.LogArtefact(nom, $"{nom} duplique l'artefact commun : {clone.Nom}", 0, false);
                        }
                    };
                })
                .Build();
        }
    }
}
