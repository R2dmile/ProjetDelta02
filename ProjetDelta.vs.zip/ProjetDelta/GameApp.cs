using System;
using System.Collections.Generic;
using ProjetDelta.Data.DataClasses;
using ProjetDelta.Data.DataLoader;
using ProjetDelta.Donjon;
using ProjetDelta.Donjon.Monstres;
using ProjetDelta.Donjon.Rooms;
using ProjetDelta.Jeu;
using ProjetDelta.Player;
using ProjetDelta.Player.ProjetDelta.PlayerLoader;
using ProjetDelta.UI;
using ProjetDelta.Systemes.events;
using ProjetDelta.Artifacts;
using ProjetDelta.Systemes;
using System.Linq;

public class GameApp
{
    private readonly IUI _ui;

    public GameApp(IUI ui)
    {
        _ui = ui;
    }

    public void Run(string[] args)
    {
        bool testArtefact = args.Any(a =>
            string.Equals(a, "--test-artefact", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(a, "-t", StringComparison.OrdinalIgnoreCase));
        bool randomDungeon = true || args.Any(a =>
            string.Equals(a, "--random-dungeon", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(a, "-r", StringComparison.OrdinalIgnoreCase));

        _ui.Afficher("Debut du jeu");

        var profile = ProfileLoader.Load();
        // Si la meta est debloquee sans avoir battu le boss final, la reverrouiller
        if (profile.MetaUnlocked && !profile.FinalBossBeaten)
        {
            profile.MetaUnlocked = false;
            ProfileLoader.Save(profile);
        }
        var finalBossData = FinalBossLoader.Load();
        _ui.Afficher($"Meta-currency : {profile.MetaCurrency} | Bosses vaincus (total): {profile.BossesDefeated}");

        if (testArtefact)
        {
            _ui.Afficher("Mode test artefact - combat de demonstration");
            DemoArtefactCombat();
            return;
        }

        while (true)
        {
            List<JoueurData> joueursSauvegardes = PlayerLoadeur.ChargerTous()
                .Where(j => !j.Mort)
                .ToList();
            string choix = "";
            Joueur joueur = null;
            while (joueur == null)
            {
                var menuOptions = new Dictionary<string, string>()
                {
                    {"1", "Creer un personnage"},
                    {"2", "Charger un personnage"},
                    {"3", profile.MetaUnlocked ? "Boutique meta (perso)" : "Boutique meta (verrouillee)"},
                    {"4", "Quitter le jeu"}
                };
                var nonSelectable = new List<string>();
                if (!profile.MetaUnlocked) nonSelectable.Add("3");
                if (joueursSauvegardes.Count == 0) nonSelectable.Add("2");
                choix = _ui.ChoisirOption("Voulez-vous :", menuOptions, nonSelectable).Item1;

                if (choix == "3")
                {
                    if (!profile.MetaUnlocked)
                    {
                        _ui.Afficher("Boutique meta verrouillee. Bats le boss final pour la debloquer.");
                        continue;
                    }
                    AfficherBoutiqueMeta(profile);
                    continue;
                }
                if (choix == "4")
                {
                    Environment.Exit(0);
                }

                var difficulteChoisie = "";
                joueur = choix switch
                {
                    "1" => new PlayerCreator().CreationJoueur(_ui, joueursSauvegardes.Select(j => j.Nom).Concat(finalBossData?.Nom is null ? Array.Empty<string>() : new[] { finalBossData.Nom })),
                    "2" => _ui.ChoisirOption("Personnages disponibles : ", joueursSauvegardes,
                                j =>
                                {
                                    var room = string.IsNullOrWhiteSpace(j.RoomName) ? "GoldenVault" : j.RoomName;
                                    var artefacts = (j.Artefacts != null && j.Artefacts.Count > 0)
                                        ? string.Join(", ", j.Artefacts)
                                        : "aucun artefact";
                                    return $"{j.Nom} - {j.ClasseNom} - {j.BackgroundNom} - Nv {j.Niveau} - Salle: {room} - PV: {j.Stats.VieCourante}/{j.Stats.VieMax} - Artefacts: {artefacts} | Diff: {j.Difficulte}";
                                })
                             .ToJoueur(),
                    _ => throw new Exception("Option invalide")
                };
                if (choix == "1")
                {
                    difficulteChoisie = ChoisirDifficulte(profile);
                    joueur.SetDifficulte(difficulteChoisie);
                    _ui.Afficher("Creation du personnage...");
                    PlayerLoadeur.Sauvegarder(joueur);
                }
            }

            joueur.AppliquerMetaBonuses(profile.MetaGoldBonus, profile.MetaLootBonus);
            MonstreBuilder.CurrentDifficulty = DifficultyModifier.FromLevel(joueur.DifficulteLevel);


            _ui.Afficher($"Bonjour, {joueur.Nom}");
            _ui.Afficher($"Salle courante: {(string.IsNullOrWhiteSpace(joueur.RoomName) ? "GoldenVault" : joueur.RoomName)}");
            _ui.Afficher($"PV: {joueur.PV}/{joueur.PVMax}");
            if (joueur.Artefacts.Count > 0)
            {
                _ui.Afficher("Artefacts equipes : " + string.Join(", ", joueur.Artefacts.Select(a => a.Nom)));
            }
            else
            {
                _ui.Afficher("Aucun artefact equipe.");
            }

            RoomLoader loader = new RoomLoader();
            Dictionary<string, Room> rooms = loader.GetRooms(randomDungeon, joueur.Etage);

            // Enregistrer les commandes globales (ex: "artifacts")
            UIText.SetCommandHook(cmd => CommandHandler.TryHandle(cmd, joueur, _ui));

            // starting point : reprendre la room sauvegardee si elle existe, sinon debut
            string startRoomName = string.IsNullOrWhiteSpace(joueur.RoomName) ? "GoldenVault" : joueur.RoomName;
            if (!rooms.TryGetValue(startRoomName, out var currentRoom))
            {
                currentRoom = rooms["GoldenVault"];
                joueur.RoomName = currentRoom.Name;
            }

            int bossesThisRun = 0;

            while (currentRoom != null)
            {
                try
                {
                    currentRoom.ResolveRoom(_ui, joueur);
                    // Pas de pause si c'est une intersection (embranchement)
                    // Ne pas imposer de pause apres un embranchement ou une boutique
                    if (currentRoom is not IntersectionRoom && currentRoom is not ShopRoom)
                    {
                        _ui.QuestionReponse("Appuie sur 1 (ou entrer) pour continuer");
                    }
                    if (currentRoom is CombatRoom combatRoom && combatRoom.IsBoss && joueur.EstVivant())
                    {
                        bossesThisRun++;
                        profile.BossesDefeated += 1;
                        var diff = DifficultyModifier.FromName(joueur.Difficulte);
                        if (diff.Level >= profile.HighestDifficultyUnlocked && profile.HighestDifficultyUnlocked < 10)
                        {
                            profile.HighestDifficultyUnlocked = diff.Level + 1;
                            var nomDiff = DifficultyModifier.FromLevel(profile.HighestDifficultyUnlocked).Nom;
                            _ui.Afficher($"Nouvelle difficulte debloquee : {nomDiff}");
                        }
                        ProfileLoader.Save(profile);

                        if (joueur.Etage >= 5)
                        {
                            _ui.Afficher("Felicitations pour le tutoriel, le veritable jeu commence maintenant !");
                            if (!profile.MetaUnlocked)
                            {
                                profile.MetaUnlocked = true;
                                profile.FinalBossBeaten = true;
                                ProfileLoader.Save(profile);
                                _ui.Afficher("Meta-progression debloquee ! Un nouvel onglet boutique est disponible au menu principal.");
                            }
                            // Sauvegarder ce joueur comme futur boss final
                            FinalBossLoader.Save(joueur);
                            PlayerLoadeur.Sauvegarder(joueur);
                            _ui.Afficher("Retour au menu principal...");
                            currentRoom = null;
                            break;
                        }
                        joueur.AvancerEtage();
                        joueur.RoomName = "GoldenVault";
                        rooms = loader.GetRooms(randomDungeon, joueur.Etage);
                        currentRoom = rooms["GoldenVault"];
                        PlayerLoadeur.Sauvegarder(joueur);
                        continue;
                    }
                    currentRoom = currentRoom.GetNextRoom();
                    joueur.RoomName = currentRoom?.Name;
                    PlayerLoadeur.Sauvegarder(joueur);
                }
                catch (GameOverException e)
                {
                    PlayerLoadeur.Supprimer(joueur.Nom); // permadeath : effacer la save
                    currentRoom = null;
                    _ui.Degats(e.Message);
                    if (profile.MetaUnlocked && bossesThisRun > 0)
                    {
                        int Tri(int n) => n * (n + 1) / 2;
                        int gain = Tri(bossesThisRun) * 10;
                        profile.MetaCurrency += gain;
                        ProfileLoader.Save(profile);
                        _ui.Afficher($"Meta-progression : tu recuperes {gain} fragments (total: {profile.MetaCurrency}).");
                    }
                    _ui.Afficher("Mort... retour au menu principal.");
                    break; // revenir au menu principal
                }

            }

            // boucle infinie pour retourner au menu apres un run
        }
    }

    private string ChoisirDifficulte(ProfileData profile)
    {
        // Construire les niveaux disponibles (0..10)
        var niveaux = Enumerable.Range(0, 11)
            .Select(DifficultyModifier.FromLevel)
            .ToList();
        int maxUnlock = Math.Min(profile.HighestDifficultyUnlocked, niveaux.Count - 1);

        var options = new Dictionary<string, string>();
        var keyToName = new Dictionary<string, string>();
        int idx = 1;
        foreach (var diff in niveaux.Where(d => d.Level <= maxUnlock))
        {
            var desc = diff.Level switch
            {
                0 => " (ennemis un peu plus faibles)",
                1 => " (baseline)",
                2 => " (renforces)",
                _ => $" ({diff.HpMult:0.00}x stats, {diff.Level} artefacts triang.)"
            };
            options[idx.ToString()] = $"{diff.Nom}{desc}";
            keyToName[idx.ToString()] = diff.Nom;
            idx++;
        }
        var choix = _ui.ChoisirOption("Choisis la difficulte :", options).Item1;
        return keyToName[choix];
    }

    private void AfficherBoutiqueMeta(ProfileData profile)
    {
        while (true)
        {
            _ui.Afficher($"Meta-currency actuelle : {profile.MetaCurrency}");
            var options = new Dictionary<string, string>
        {
            {"1", $"+1% chance drop artefact permanent (cout 50)"},
            {"2", $"+5% or permanent (cout 50)"},
            {"0", "Quitter la boutique meta"}
        };
            var choix = _ui.ChoisirOption("Boutique meta :", options).Item1;
            if (choix == "0") return;
            if (choix == "1")
            {
                const int cout = 50;
                if (profile.MetaCurrency < cout)
                {
                    _ui.Afficher("Pas assez de meta-currency.");
                    continue;
                }
                profile.MetaCurrency -= cout;
                profile.MetaLootBonus += 0.01f;
                _ui.Afficher($"Achat effectue. Bonus drop total : {MathF.Round(profile.MetaLootBonus * 100, 1)}%");
            }
            else if (choix == "2")
            {
                const int cout = 50;
                if (profile.MetaCurrency < cout)
                {
                    _ui.Afficher("Pas assez de meta-currency.");
                    continue;
                }
                profile.MetaCurrency -= cout;
                profile.MetaGoldBonus += 0.05f;
                _ui.Afficher($"Achat effectue. Bonus or total : {MathF.Round(profile.MetaGoldBonus * 100, 1)}%");
            }
            ProfileLoader.Save(profile);
        }
    }

    private void DemoArtefactCombat()
    {
        var bg = new Background
        {
            Nom = "TestBG",
            Description = "Contexte test",
            Attributs = new AttributsDto(0, 0, 0, 0, 0) { MulConst = 1, MulDex = 1, MulForce = 1, MulIntel = 1 }
        };
        var cl = new Classe
        {
            Nom = "TestClasse",
            Description = "Classe test",
            Attributs = new AttributsDto(0, 0, 0, 0, 0) { MulConst = 1, MulDex = 1, MulForce = 1, MulIntel = 1 }
        };

        var hero = new Joueur("HeroTest", bg, cl, new Stats(30, 30, 6, 10));
        var gob = new Monstre("GobTest", "red", new Attributs(), new Stats(20, 20, 3, 6));

        var artefacts = ArtefactLoader.ChargerDepuisJson();
        // Artefacts du heros (depuis le JSON)
        hero.EquipArtefact(artefacts["poison2"]);
        hero.EquipArtefact(artefacts["heal_atk1"]);
        hero.EquipArtefact(artefacts["regen2"]);
        hero.EquipArtefact(artefacts["shield20"]);
        hero.EquipArtefact(artefacts["shield10"]); // second bouclier pour voir l'interaction

        // Artefacts du gobelin
        gob.EquipArtefact(artefacts["regen2"]);
        gob.EquipArtefact(artefacts["armor1"]);
        gob.EquipArtefact(artefacts["thorns"]);

        var combat = new Combat(hero, new List<Monstre> { gob }, _ui);
        combat.Demarrer();
    }
}
