﻿using ProjetDelta.Systemes.UIJeu;
using ProjetDelta.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Logger
{
    public class CombatLogger : ICombatLogger
    {
        private List<CombatDataItem> _logs;

        public CombatLogger(List<CombatDataItem> logs)
        {
            _logs = logs;
        }

        public void Log(CombatDataItem item)
        {
            _logs.Add(item);
        }
       
        public void AfficherAvecDelais(IUI ui)
        {
            int count = _logs.Count;
            int baseDelay = 1333; // délai constant max pour les courts combats
            int minDelay = 20;
            double maxTotalTime = 50000;
            double sumDelays = 0;
            int seuilAcceleration = 20; // seuil pour commencer l’accélération

            double[] delays = new double[count];
            for (int i = 0; i < count; i++)
            {
                if (count <= seuilAcceleration)
                {
                    // Pas d'accélération : délai constant pour chaque coup
                    delays[i] = baseDelay;
                }
                else
                {
                    double progress = (double)i / (count - 1);
                    double accelerationPower = 10;
                    double factor = progress == 1 ? 1 : 1 - Math.Pow(2, -accelerationPower * progress);

                    delays[i] = baseDelay - factor * (baseDelay - minDelay);
                }
                sumDelays += delays[i];
            }

            double scalingFactor = 1.0;
            if (sumDelays > maxTotalTime)
            {
                scalingFactor = maxTotalTime / sumDelays;
            }

            UIJeuSendConsole uijeu = new UIJeuSendConsole(ui);

            for (int i = 0; i < count; i++)
            {
                uijeu.AfficherCombatItem(_logs[i]);

                int scaledDelay = (int)(delays[i] * scalingFactor);
                if (scaledDelay > baseDelay)
                    scaledDelay = baseDelay;

                Thread.Sleep(scaledDelay);
            }
        }
    }

}
