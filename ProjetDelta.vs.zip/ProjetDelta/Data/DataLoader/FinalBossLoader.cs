using ProjetDelta.Data.DataClasses;
using ProjetDelta.Artifacts;
using ProjetDelta.Player;
using System.Text.Json;

namespace ProjetDelta.Data.DataLoader
{
    public static class FinalBossLoader
    {
        private static string ResolvePath()
        {
            var baseDirPath = Path.Combine(AppContext.BaseDirectory, "Data", "DataStorage", "finalboss.json");
            if (File.Exists(baseDirPath) || Directory.Exists(Path.GetDirectoryName(baseDirPath)))
                return baseDirPath;
            return Path.Combine("..", "..", "..", "Data", "DataStorage", "finalboss.json");
        }
        private static JoueurData? _cache;

        public static JoueurData? Load()
        {
            if (_cache != null) return _cache;
            var filePath = ResolvePath();
            if (!File.Exists(filePath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filePath));
                File.WriteAllText(filePath, "{}");
                return null;
            }
            var json = File.ReadAllText(filePath);
            _cache = JsonSerializer.Deserialize<JoueurData>(json);
            return _cache;
        }

        public static void Save(Joueur joueur)
        {
            var filePath = ResolvePath();
            var data = joueur.ToData();
            // S'assurer que le boss sauvegardé est full PV
            data.Stats = new Stats(data.Stats.VieMax, data.Stats.VieMax, data.Stats.Attaque, data.Stats.Vitesse);
            var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
            _cache = data;
        }

        public static bool Exists()
        {
            return Load() != null;
        }

        public static string? GetName()
        {
            return Load()?.Nom;
        }
    }
}
