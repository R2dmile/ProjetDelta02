using ProjetDelta.Data.DataClasses.Rooms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using ProjetDelta.Donjon.Monstres;
using ProjetDelta.Donjon.Rooms;
using ProjetDelta.Data.DataLoader;

namespace ProjetDelta.Data.DataLoader
{
    public class RoomLoader
    {
        private readonly MonstreBuilder _builder = new();

        /// <summary>
        /// Charge les salles. Si randomize = true, construit une progression lineaire: start (GoldenVault) -> salles melangees -> boss (FinalFight)
        /// en ne gardant que les types lineaires (Combat, Shop, Treasure, SkillCheck) pour l'intermediaire.
        /// </summary>
        public Dictionary<string, Room> GetRooms(bool randomize = false, int etage = 1)
        {
            string roomsFilePath = ResolvePath();
            string json = File.ReadAllText(roomsFilePath);

            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            RawRoomList rawRoomList = JsonSerializer.Deserialize<RawRoomList>(json, options);

            return randomize
                ? BuildRandomizedRooms(rawRoomList.rooms, etage)
                : BuildRooms(rawRoomList.rooms, etage);
        }

        private string ResolvePath()
        {
            var candidates = new[]
            {
                Path.Combine(AppContext.BaseDirectory, "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine(AppContext.BaseDirectory, "..", "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine(AppContext.BaseDirectory, "..", "..", "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine(AppContext.BaseDirectory, "net8.0", "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine(Directory.GetCurrentDirectory(), "Data", "DataStorage", "rooms", "rooms.json"),
                Path.Combine("..", "..", "..", "Data", "DataStorage", "rooms", "rooms.json")
            }
            .Select(p => Path.GetFullPath(p))
            .ToList();
            var found = candidates.FirstOrDefault(File.Exists);
            return found ?? Path.Combine("..", "..", "..", "Data", "DataStorage", "rooms", "rooms.json");
        }

        private Dictionary<string, Room> BuildRooms(IEnumerable<RawRoom> raws, int etage)
        {
            Dictionary<string, Room> createdRooms = new();

            foreach (RawRoom raw in raws)
            {
                var room = CreateRoom(raw, etage);
                room.SetNextRoomName(raw.next);
                createdRooms[raw.name] = room;
            }

            foreach (var room in createdRooms.Values)
            {
                room.ResolveLinks(createdRooms);
            }
            return createdRooms;
        }

        private Dictionary<string, Room> BuildRandomizedRooms(IEnumerable<RawRoom> raws, int etage)
        {
            var list = raws.ToList();
            var start = list.FirstOrDefault(r => string.Equals(r.name, "GoldenVault", StringComparison.OrdinalIgnoreCase))
                        ?? list.FirstOrDefault();
            var boss = list.FirstOrDefault(r => string.Equals(r.name, "FinalFight", StringComparison.OrdinalIgnoreCase))
                       ?? list.LastOrDefault();

            var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "CombatRoom", "ShopRoom", "TreasureRoom", "IntersectionRoom", "FountainRoom", "ShrineRoom" };

            var mid = list.Where(r => r != start && r != boss && allowed.Contains(r.type)).ToList();

            var rng = new Random();
            mid = mid.OrderBy(_ => rng.Next()).ToList();

            // Extraire des pools par type pour garantir une cadence
            var shops = mid.Where(r => string.Equals(r.type, "ShopRoom", StringComparison.OrdinalIgnoreCase)).ToList();
            var treasures = mid.Where(r => string.Equals(r.type, "TreasureRoom", StringComparison.OrdinalIgnoreCase)).ToList();
            var remaining = mid.Where(r =>
                !string.Equals(r.type, "ShopRoom", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(r.type, "TreasureRoom", StringComparison.OrdinalIgnoreCase)).ToList();

            int shopInterval = 3;       // un shop tous les 3 combats environ
            int treasureInterval = 2;   // une salle tresor toutes les 2 salles environ

            int combatsDepuisShop = 0;
            int roomsDepuisTresor = 0;

            var assembledMid = new List<RawRoom>();
            foreach (var room in remaining)
            {
                assembledMid.Add(room);
                if (string.Equals(room.type, "CombatRoom", StringComparison.OrdinalIgnoreCase))
                {
                    combatsDepuisShop++;
                }
                roomsDepuisTresor++;

                if (combatsDepuisShop >= shopInterval && shops.Count > 0)
                {
                    assembledMid.Add(shops[0]);
                    shops.RemoveAt(0);
                    combatsDepuisShop = 0;
                    roomsDepuisTresor++;
                }

                if (roomsDepuisTresor >= treasureInterval && treasures.Count > 0)
                {
                    assembledMid.Add(treasures[0]);
                    treasures.RemoveAt(0);
                    roomsDepuisTresor = 0;
                }
            }

            // Ajouter les shops/tresors restants en fin de parcours avant le boss
            foreach (var s in shops) assembledMid.Add(s);
            foreach (var t in treasures) assembledMid.Add(t);

            var ordered = new List<RawRoom>();
            if (start != null) ordered.Add(start);
            ordered.AddRange(assembledMid);
            if (boss != null && boss != start) ordered.Add(boss);

            for (int i = 0; i < ordered.Count; i++)
            {
                ordered[i].next = (i + 1 < ordered.Count) ? ordered[i + 1].name : null;
            }

            return BuildRooms(ordered, etage);
        }

        private Room CreateRoom(RawRoom raw, int etage)
        {
            return raw.type switch
            {
                "CombatRoom" => new CombatRoom(
                    raw.name,
                    OverrideDescriptionIfFinal(raw),
                    BuildCombatants(raw, etage),
                    raw.boss || string.Equals(raw.name, "FinalFight", StringComparison.OrdinalIgnoreCase)
                ),
                "ShopRoom" => new ShopRoom(
                    raw.name,
                    raw.description,
                    raw.items ?? new List<string>()
                ),
                "TreasureRoom" => MaybeTreasureFight(raw, etage),
                "IntersectionRoom" => new IntersectionRoom(
                    raw.name,
                    raw.description,
                    raw.choices ?? new Dictionary<string, string>()
                ),
                "FountainRoom" => new FountainRoom(
                    raw.name,
                    raw.description
                ),
                "SkillCheckRoom" => new ShrineRoom(
                    raw.name,
                    raw.description
                ),
                "ShrineRoom" => new ShrineRoom(
                    raw.name,
                    raw.description
                ),
                _ => throw new Exception($"Type inconnu : {raw.type}")
            };
        }

        private Room MaybeTreasureFight(RawRoom raw, int etage)
        {
            // 50% de chance de transformer en salle risk/reward
            var rand = new Random();
            bool risk = rand.NextDouble() < 0.5;
            if (risk)
            {
                return new TreasureFightRoom(
                    raw.name,
                    raw.description,
                    raw.treasure ?? "Tresor inconnu",
                    _builder,
                    etage
                );
            }
            return new TreasureRoom(
                raw.name,
                raw.description,
                raw.treasure ?? "Tresor inconnu"
            );
        }

        private string OverrideDescriptionIfFinal(RawRoom raw)
        {
            if (string.Equals(raw.name, "FinalFight", StringComparison.OrdinalIgnoreCase))
            {
                var fb = FinalBossLoader.Load();
                if (fb != null)
                {
                    return $"Sur le trone, une figure familiere se dresse : {fb.Nom}";
                }
            }
            return raw.description;
        }

        private List<Monstre> BuildCombatants(RawRoom raw, int etage)
        {
            var result = new List<Monstre>();
            // Autoriser les noms explicites uniquement pour les boss/salles speciales
            bool explicitAllowed = raw.boss || string.Equals(raw.name, "FinalFight", StringComparison.OrdinalIgnoreCase);
            if (explicitAllowed && raw.monsters != null && raw.monsters.Count > 0 && raw.monsters.All(m => !m.StartsWith("__random", StringComparison.OrdinalIgnoreCase)))
            {
                result.AddRange(raw.monsters.Select(name => _builder.CreerMonstre(name)));
                // Si un placeholder "slime" a ete genere, fallback sur generation par tiers
                if (result.Any(m => m.Nom.Equals("slime", StringComparison.OrdinalIgnoreCase)))
                {
                    result.Clear();
                }
                else
                {
                    return result;
                }
            }

            // Combat generé selon l'etage
            int tierA = 1;
            int tierB = Math.Max(1, Math.Min(etage, 7));
            int bossTier = Math.Min(7, etage + 2);
            var tiersPool = new[] { tierA, tierB }.Distinct().ToList();

            // Embranchements risk/reward : chance d'un combat "elite" avec un tier +1 qui droppe un artefact garanti
            bool eliteBranch = raw.type != null && raw.type.Equals("IntersectionRoom", StringComparison.OrdinalIgnoreCase) && new Random().NextDouble() < 0.3;
            if (eliteBranch)
            {
                tiersPool = new[] { Math.Min(7, tierB + 1) }.ToList();
                var elite = _builder.CreerMonstreParTiers(tiersPool);
                // drop garanti : on equip un artefact commun immediatement apres
                    var dtos = ArtefactLoader.GetDtos()
                    .Where(d => string.IsNullOrWhiteSpace(d.Rarity) || d.Rarity.Equals("common", StringComparison.OrdinalIgnoreCase))
                    .ToList();
                    if (dtos.Count > 0)
                    {
                        var randLocal = new Random();
                        var dto = dtos[randLocal.Next(dtos.Count)];
                    var art = ArtefactLoader.CreerInstance(dto.Id ?? dto.Nom ?? "");
                    if (art != null)
                    {
                        elite.EquipArtefact(art);
                    }
                }
                return new List<Monstre> { elite };
            }
            // Boss special
            if (raw.boss || string.Equals(raw.name, "FinalFight", StringComparison.OrdinalIgnoreCase))
            {
                if (etage >= 5)
                {
                    result.Add(_builder.CreerBossFinal());
                    return result;
                }
                result.Add(_builder.CreerMonstreParTier(bossTier));
                return result;
            }

            // 1 a 2 monstres pour les combats standard
            int count = 1;
            var rand = new Random();
            if (rand.NextDouble() > 0.6) count = 2;
            for (int i = 0; i < count; i++)
                result.Add(_builder.CreerMonstreParTiers(tiersPool));
            return result;
        }
    }
}
