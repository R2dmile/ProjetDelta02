using ProjetDelta.Data.DataClasses;
using System.Text.Json;

namespace ProjetDelta.Data.DataLoader
{
    public static class ProfileLoader
    {
        private static string ResolvePath()
        {
            // Préfère le dossier Data/DataStorage à côté de l'exécutable (publish)
            var baseDirPath = Path.Combine(AppContext.BaseDirectory, "Data", "DataStorage", "profile.json");
            if (File.Exists(baseDirPath) || Directory.Exists(Path.GetDirectoryName(baseDirPath)))
                return baseDirPath;

            // Fallback mode dev
            return Path.Combine("..", "..", "..", "Data", "DataStorage", "profile.json");
        }

        public static ProfileData Load()
        {
            var filePath = ResolvePath();
            if (!File.Exists(filePath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filePath) ?? ".");
                var def = new ProfileData();
                Save(def);
                return def;
            }

            var json = File.ReadAllText(filePath);
            var data = JsonSerializer.Deserialize<ProfileData>(json);
            return data ?? new ProfileData();
        }

        public static void Save(ProfileData profile)
        {
            var filePath = ResolvePath();
            Directory.CreateDirectory(Path.GetDirectoryName(filePath) ?? ".");
            var json = JsonSerializer.Serialize(profile, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }
    }
}
