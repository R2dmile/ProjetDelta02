﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Data.DataLoader
{
    using global::ProjetDelta.Data.DataClasses;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.Json;

    namespace ProjetDelta.Narration
    {
        public static class SectionLoader
        {
            public static List<Section> ChargerSections()
            {
                string filePath = Path.Combine("..", "..", "..", "Data", "DataStorage", "sections3.json");
                try
                {
                    string json = File.ReadAllText(filePath);
                    var sectionsData = JsonSerializer.Deserialize<Section.SectionsData>(json);
                    return sectionsData?.Sections; // Ajout du ?. pour gérer les cas où sectionsData est null
                }
                catch (Exception ex)
                {
                    // log
                    Console.WriteLine($"Erreur lors du chargement des sections : {ex.Message}");
                    return null;
                }
            }

        }
    }

}
