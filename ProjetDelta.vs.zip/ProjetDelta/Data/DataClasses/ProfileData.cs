namespace ProjetDelta.Data.DataClasses
{
    public class ProfileData
    {
        public int MetaCurrency { get; set; } = 0;
        public int BossesDefeated { get; set; } = 0;
        public bool MetaUnlocked { get; set; } = false;
        public bool FinalBossBeaten { get; set; } = false;
        public float MetaGoldBonus { get; set; } = 0f;
        public float MetaLootBonus { get; set; } = 0f;
        public int HighestDifficultyUnlocked { get; set; } = 0; // 0 = Facile, 1 = Normal, 2 = Difficile, ...
    }
}
