﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Data.DataClasses
{
    public abstract class BaseOption
    {
        public string Nom { get; set; }
        public string Description { get; set; }
        public AttributsDto Attributs { get; set; }
        public string? ArtefactId { get; set; }

        public abstract void AdjustAttributes(Attributs attributs);
    }
}
