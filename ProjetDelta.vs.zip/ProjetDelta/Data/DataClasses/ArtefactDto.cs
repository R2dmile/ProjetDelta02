using System.Text.Json.Serialization;

namespace ProjetDelta.Data.DataClasses
{
    public class ArtefactDto
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("nom")]
        public string? Nom { get; set; }

        [JsonPropertyName("valeur")]
        public float? Valeur { get; set; }

        [JsonPropertyName("valeur2")]
        public float? Valeur2 { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("rarity")]
        public string? Rarity { get; set; }
    }
}
