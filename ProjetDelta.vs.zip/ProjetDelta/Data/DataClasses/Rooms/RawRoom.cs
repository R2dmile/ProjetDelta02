﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetDelta.Data.DataClasses.Rooms
{
    public class RawRoom
    {
        public string type { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string treasure { get; set; }
        public List<string> items { get; set; }
        public List<string> monsters { get; set; }
        public string next { get; set; }
        public Dictionary<string, string> choices { get; set; }
        public string attribute { get; set; }
        public int difficulty { get; set; }
        public string success { get; set; }
        public string fail { get; set; }
        public int rewardGold { get; set; }
        public int failDamage { get; set; }
        public bool boss { get; set; }
    }
    public class RawRoomList
    {
        public List<RawRoom> rooms { get; set; }
    }
}
