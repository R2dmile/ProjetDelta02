﻿using ProjetDelta.Systemes;

namespace ProjetDelta.UI
{
    class UIText : IUI
    {
        private static Func<string, bool>? _commandHook;

        public static void SetCommandHook(Func<string, bool> hook)
        {
            _commandHook = hook;
        }

        public UIText() { }

        public void Afficher(string text)
        {
            Console.WriteLine(" " + text + "\n");
        }

        public void AffichageBasicInteractif(string text, string couleur)
        {
            switch (couleur)
            {
                case "red":
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case "green":
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    break;
                case "yellow":
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case "gray":
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "lime":
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case "gold":
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                default:break;
            }
            Console.Write(" " + text);
            Console.ResetColor();
        }

        public void AfficherNonSelectionnable(string text)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" " + text + "\n");
            Console.ResetColor();
        }
        public void Degats(string text)
        { Console.WriteLine(" " + text + "\n"); }
        public void Effet(string text)
        { Console.WriteLine(" " + text + "\n"); }
        public string QuestionReponse(string question = "")
        {
            string input;
            do
            {
                Console.Write(" " + question + "\n");
                input = Console.ReadLine();
                if (!string.IsNullOrEmpty(input) && _commandHook != null && _commandHook.Invoke(input))
                {
                    // commande traitee, on relance la question
                    input = "";
                }
            } while (string.IsNullOrEmpty(input));

            return input;
        }
        //à rajouter choix bloqués
        public (string, string) ChoisirOption(string titre, Dictionary<string, string> options)
        {
            bool choixValide = false;
            string selectionKey = "";
            string selectionValue = "";
            while (!choixValide)
            {
                Afficher(titre);
                foreach (var option in options)
                {
                    Afficher($"{option.Key}. {option.Value}");
                }
                string reponse = QuestionReponse("Votre choix :");
                if (options.ContainsKey(reponse))
                {
                    selectionKey = reponse;
                    selectionValue = options[reponse];
                    choixValide = true;
                }
                else
                {
                    Afficher("Choix invalide. Veuillez réessayer.");
                }
            }
            return (selectionKey, selectionValue);
        }

        public (string, string) ChoisirOption(string titre, Dictionary<string, string> options, List<string> nonSelectableKeys)
        {
            bool choixValide = false;
            string selectionValue = "";
            string selectionKey = "";
            while (!choixValide)
            {
                Afficher(titre);
                foreach (var option in options)
                {
                    // Si l'option est non sélectionnable, on utilise AfficherNonSelectionnable
                    if (nonSelectableKeys.Contains(option.Key))
                        AfficherNonSelectionnable($"{option.Key}. {option.Value}");
                    else
                        Afficher($"{option.Key}. {option.Value}");
                }
                string reponse = QuestionReponse("Votre choix :");
                if (options.ContainsKey(reponse))
                {
                    // Vérifie si l'option choisie est non sélectionnable
                    if (nonSelectableKeys.Contains(reponse))
                    {
                        Afficher("Cette option n'est pas sélectionnable. Veuillez réessayer.");
                    }
                    else
                    {
                        selectionValue = options[reponse];
                        selectionKey = reponse;
                        choixValide = true;
                    }
                }
                else
                {
                    Afficher("Choix invalide. Veuillez réessayer.");
                }
            }
            return (selectionKey, selectionValue);
        }

        // Méthode qui demande une confirmation après le choix
        public string ChoisirOptionAvecConfirmation(string titre, Dictionary<string, string> options)
        {
            string selection = "";
            string confirmation = "";
            do
            {
                selection = ChoisirOption(titre, options).Item2;
                confirmation = QuestionReponse($"Vous avez choisi {selection}. Confirmez-vous ? (oui/non)");
            } while (confirmation.ToLower() != "oui");
            return selection;
        }
        public T ChoisirOption<T>(string titre, List<T> options, Func<T, string> optionToString)
        {
            bool choixValide = false;
            T selection = default(T);
            while (!choixValide)
            {
                Afficher(titre);
                for (int i = 0; i < options.Count; i++)
                {
                    Afficher($"{i + 1}. {optionToString(options[i])}");
                }
                string reponse = QuestionReponse("Votre choix (numéro) :");
                if (int.TryParse(reponse, out int index) && index > 0 && index <= options.Count)
                {
                    selection = options[index - 1];
                    choixValide = true;
                }
                else
                {
                    Afficher("Choix invalide. Veuillez réessayer.");
                }
            }
            return selection;
        }

        public T ChoisirOptionAvecConfirmation<T>(string titre, List<T> options, Func<T, string> optionToString)
        {
            T selection;
            string confirmation = "";
            do
            {
                selection = ChoisirOption(titre, options, optionToString);
                confirmation = QuestionReponse($"Vous avez choisi : {optionToString(selection)}. Confirmez-vous ? (oui/non)");
            } while (confirmation.ToLower() != "oui");
            return selection;
        }

        public void TerminerLigne()
        {
            Console.WriteLine("");
        }
    }
}
